�V1�   cb$�#LS0K gKEMpIDIwMTMtMTUgLSBudG9wLm9yZwotLQoKZGlycyA9IG50b3AuZ2V0R`gp
CnBhY2thZ2UucGF0aC@(RpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVhL21vZHVs
ZXMvPy5sdWE7I`,
BwYWNrYWc=
cb$�?ZS5wYXRoCnBhY2thZ2UucGF0aCA9IGRpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVh
L3Byby9tb2R1bGVzLz8u@OyIgLi4gcGFja2Fn� pgpyZXF1aXJlICJsdWFfdXRp
bHMiCgoKcHJpbnQgW1sKPHNjcmk=
cb$�?cHQ+CgogICB2YXIgdXBkYXRlX3RhbGtlcnMgPSBmdW5jdGlvbiBnZXRE #hICgpIHsgJC5n
 KU09OKCddXQoJcHJpbnQgKG50b3AuZ2V0SHR0cFByZWZpe < K�'W1svbHVh
L2dldF9ob3N0c19@�	hLmx1YT8=
cb$�?bW9kZT1sb2NhbCZjdXJyZW50UGFnZT0xJnNvcnRDb2x1bW49Y29sdW1uX3RocHQmc29ydE9y
ZGVyPWRlc2MmbG9uZ19uYW1lcz DywgZnVuY3Rpb24odG1wKSB7CgogICA�GZvciAo
dmFyIGkgPSAwOyBpIDwgdG1wLmQ=
cb$�>YXRhLmxlbmd0aDsgaSsrKSB7CgkgICA`aWYodG1wLmRhdGFbaV0uY29sdW1uX3RocHRb
MF0gPT0gIjAi`@QoJCS�<aSA9PSAw icmVhazsK@�`kKCIj Xsa2Vy
c18iK2kpLmh0bWwoIiZuYnNwOyI=
cb$�)KTsKCSAgIC`kKCIjdGFsa2Vyc18iK2krIl90cmFmZmljIikuaHRtbCgiJm5ic3A7 7
Cgp9IGVsc2UgewoJCSQoIiN0YWxrZXJzXyIraS�<PEEgSFJFRj0nIit0bXAuZGF0
YVtpXS5jb2x1bW5fdXJsKyInPiI=
cb$�?K3RtcC5kYXRhW2ldLmNvbHVtbl9uYW1lKyI8L0E+Iik7CgkJJCgiI3RhbGtlcnNfIitpKyJf
dHJhZmZpYyIpLmh0bWwodG1wLmRhdGFbaV0uY29sdW1uX3RocHQpOwp 9 TgfQkgIAp9KTsJ
CiAgIH0KICAgc2V0SW
50ZXJ2YWw=
cb$�?KHVwZGF0ZV90YWxrZXJzLCAzMDAwKTsKICAgJChkb2N1bWVudCkucmVhZHkodXBkYXRlX3Rh
bGtlcnMpOwoKPC9zY3JpcHQ+CgpdXQoKcHJpbnQgW1sKPHNjcmlwdD4KCiAgIHZhciB1cG HdGVfdGFsa2VycyA9IGZ1bmN0aW8=
cb$�6biBnZXREYXRhICgpIHsgJC5@KU09OKCddXQoJcHJpbnQgKG50b3AuZ2V0SHR0cFByZWZp
e < K�(W1svbHVhL2dldF9ob3N0c19k@hLmx1YT9tb2RlPXJlbW90ZSZjdXJy
ZW50UGFnZT0xJnNvcnRDb2x1bW4=
cb$�?PWNvbHVtbl90aHB0JnNvcnRPcmRlcj1kZXNjJmxvbmdfbmFtZXM9MScsIGZ1bmN0aW9uKHRt
cCkgewoKICAg�Bmb3IgKHZhciBpID0gMDsgaSA8I 0cC5kYXRhLmxl \0a`	sr
KSB7Cgk�DAgaWYodG1wLmQ=
cb$�?YXRhW2ldLmNvbHVtbl90aHB0WzBdID09ICIwIikgewkKCQkgIGlmKGkgPT0gMCkg
YnJlYWs7
Cg CA`JCgiI3JlbW90ZV90YWxrZXJzXyIraSkuaHRtb #Jm5ic3A7 ` 7�? 
@D�@I=
cb$�?c18iK2krIl90cmFmZmljIikuaHRtbCgiJm5ic3A7 7Cgp9IGVsc2UgewoJCSQoIiNyZW1v
dG	VfdGFsa2Vy�TpLmh0bWwoIjxBIEhSRUY9JyIrdG1wLmR h /baV0uY29sdW1uX3Vy
bCsiJz4iK3RtcC5kYXRhW2ldLmM=
cb$�?b2x1bW5fbmFtZSsiPC9BPiIpOwoJCSQoIiNyZW1vdGVfdGFsa2Vyc18iK2krIl90cmFmZmlj
IikuaHRtbCh0bXAuZGF0YVtpXS5j�ddGhwdCk7Cn0KCSB9CSAg  lkKICAgfQog
ICBzZXRJbnRlcnZh P	1cGRhdGU=
cb$r?X3RhbGtlcnMsIDMwMDApOwogICAkKGRvY3VtZW50KS5yZWFkeSh1cGRhdGVfdGFsa2Vycyk7
Cgo8L3NjcmlwdD4KCl1dCg==
