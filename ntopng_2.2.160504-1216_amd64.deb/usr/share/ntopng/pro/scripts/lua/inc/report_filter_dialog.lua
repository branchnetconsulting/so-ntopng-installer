�V1�   cb$�#LS0K gKEMpIDIwMTMtMTUgLSBudG9wLm9yZwotLQoKSFRNTGNvbnRlbnQgPSAiIg� 
�BIVE1MY29 DVudC4uW1sKCiA8c3R5bGUgdHlwZT0n 4dC9jc3MnPgou
bGFyZ2Vncm91cCB7 4	gICB3aWQ=
cb$�?dGg6NTAwcHgKfQo8L3N0eWxlPgo8ZGl2IGlkPSJyZXBvcnRfZmlsdGVyX2RpYWxvZyIgY2xh
c3M9Im1vZGFsIGZhZGUiIHRhYmluZGV4PSItMSIgcm9sZT0i \hbG9nIiBhcmlhLWx +Vs
bGVkYnk9InJlcG9ydF9maWx0ZXI=
cb$�?X2RpYWxvZ19sYWJlbCIgYXJpYS1oaWRkZW49InRydWUiPgogIDxkaXYgY2xhc3M9
Im1vZGFs
LW�HyI+CiAgICA8ZGl2IGNsYXNzPSJtb2RhbC1jb250ZW50Ij4K '@+gPGRpdiBj
bGFzcz0ibW9kYWwtaGVhZGVyIj4=
cb$�?CiAgPGJ1dHRvbiB0eXBlPSJidXR0b24iIGNsYXNz jbG9zZSIgZGF0YS1kaXNt @t
b2RhbCIgYXJp oaWRkZW49InRydWUiPng8L2�hj4KICA8aDMgaWQ #JlcG9ydF9m
aWx0ZXJfZGlh qnX2xhYmVsIj4=
cb$�?RmlsdGVyIFJlcG9ydDwvaDM+CjwvZGl2PgoKPGRpdiBjbGFzcz0ibW9kYWwtYm9keSI+Cgo8
c2NyaXB0PgpmdW5jdGlvbiB0b2dnbGVpbnRmcyhzb3VyY2UpIHsKICBjaGVja2JveGVzID0g
ZG9jdW1lbnQuZ2V0RWxlbWVudHM=
cb$�?QnlOYW1lKCdpbnRlcmZhY2VzJyk7CiAgZm9yKHZhciBpPTAsIG49Y2hlY2tib3hlcy5sZW5n
dGg7aTxuO2krKykgewogICA g�,1tpXS5jaGVja2VkID0gc291cmNlLmNoZWNr
ZWQ`yfQp9CmZ1bmN0aW9uIHQ=
cb$�?b2dnbGVuZHBpKHNvdXJjZSkgewogIGNoZWNrYm94ZXMgPSBkb2N1bWVudC5nZXRF ;tZW50
c0J5TmFtZSgnbDdwcm90b3MnKTsKICBmb3IodmFyIGk9MCwgbj1jaGVja2JveGVzLmxlbmd0
aDtpPG47aSsrKSB7CiAgICBjaGU=
cb$�?Y2tib3hlc1tpXS5jaGVja2VkID0gc291cmNlLmNoZWNrZWQ7CiAgfQp9Cjwvc2NyaXB0PgoK
PGRpdiBjbGFzcz0iY29udHJvbC1ncm HCIgc3R5bGU9ImZsb2F0OmxlZnQ7Ij4KPGxhYmVs
IGZvcj0iI�LI=
cb$�?b2wtbGFiZWwiPk5ldHdvcmsgSW50ZXJmYWNlczwv�#+CjxkaXYgY2xhc3M9ImlucHV0
LWdyb3VwIj4KPGRpdiBzdHlsZT0id2lkdGg6IDIwMHB4OyBoZWlnaHQ�vdmVy
Zmxvdy15OiBhdXRv`PHVsIHM=
cb$�/dHlsZT0ibGlzdC1z`S10eXBlOiBub25lOyBwYWRkaW5nLWxlZnQ6MDsiPl1dCgpIVE1M
Y29udGVudCA9IEhUTUxj <0ZW50Li5bWzxsaT48 DwdXQgdHlw@xY2hlY2tib3giIG9u
Q2xpY2s9InRvZ2dsZWludGZzKHQ=
cb$�?aGlzKSI+IFRvZ2dsZSBBbGw8L2xpPl1dCmZvciBrLHYgaW4gcGFpcnNCeVZhbHVlcyhuYW1l
cywgcmV2KSBkbwogIEhUTUxjb250ZW50ID0gSFRNTGNvbnRlbnQuLltbPG hjxpbnB mB0
eXBlPSJjaGVja2JveCIgbmFtZT0=
cb$�?ImludGVyZmFjZXMiIGNsYXNzPSJpbnRmY2hlY2tib3giIF1dCiAgaWYoKG5leHQoaW50ZnNf
c2VsZWN0ZWQpID09IG5pbCBhbmQ 0ZuYW1l`HYpIG9yIGhhc0tleSh2LCB`lc19z
ZWxlY3RlZCkpIHRoZW4gSFRNTGM=
cb$�?b250ZW50ID0gSFRNTGNvbnRlbnQuLiJjaGVja2VkIiBlbmQKICBIVE1MY29udGVudCA9IEhU
TUxj�LLi5bWyB2YWx1ZT0iXV0uLnYuLltbIj4g`mdldEl@DyZmFjZU5hbWVB
bGlhcyh2KS4uW1s8L2
xpPl1dCmU=
cb$�?bmQKCkhUTUxjb250ZW50ID0gSFRNTGNvbnRlbnQuLltbPC91bD4K kaXY+CjwvZGl2Pgo8
L2Rpdj4KCjx@
gY2xhc3M9Im`Dyb2wtZ3JvdXAi@0bGFiZWwgZm9yPSIiIGNsYXNz
PSJ`�cm9sLWxhYmVsIj5Qcm8=
cb$�?dG9jb2xzPC9sYWJlbD4KPGRpdiBjbGFzcz0iaW5wdXQtZ3JvdXAiPgo8ZGl2IHN0eWxlPSJ3
aWR0aDogMjAwcHg7IGhlaWdod�92ZXJmbG93LXk6IGF1dG8`PdWwgc3R5
bGU9Imxpc3Qt@ 	tdHlwZTo=
cb$�?IG5vbmU7IHBhZGRpbmctbGVmdDowOyI+XV0KCmludGVyZmFjZS5zZWxlY3QoaWZuYW1lKQps
b2NhbCBzdGF0cyA9IGFnZ3JlZ2F0ZU�@VN0YXRzKG�S5nZXRT@;
cygp@Q�Pb3J0X2Z1bmM=
cb$�?ID0gZnVuY3Rpb24oYSwgYikgcmV0dXJuIGEgPCBiIGVuZAp0YWJsZS5zb3J0KHN0YXRzWyJu
ZHBpIl0sIHNvcnRf`TykKbG9jYWwgaSA9IDE� c29ydGVkX25kcGkgPSB7fQpm
b3IgayBpbiBwYWlycyhzdGF0c1s=
cb$�?Im5kcGkiXSkgZG8KICBzb3J0ZWRfbmRw
aVtpXSA9IGs@pID0gaSArIDEKZW5kCmxvY2Fs
IHNvcnRlZF9uZHBpX25leHQgPSBnZXRLZXlzU29ydGVkQnlWYWx1ZSh�lSwg
c@$F9mdW5jKQpsb2NhbCBzb3I=
cb$�?dGVkX25kcGlfZmluYWwgPSB7fQppID0gMQpmb3Igayx2IGluIHBhaXJzKHNvcnRlZF9uZHBp
 DleHQpIGRvCiAgc29y�	\xbaV0@`zb3J0ZWRfbmRwaVt2XQogIGkg
 }pICs@ylbmQKSFRNTGNvbnQ=
cb$�?ZW50ID0gSFRNTGNvbnRlbnQuLltbPGxpPjxpbnB1dCB0eXBlPSJjaGVja2JveCIgb25DbGlj
az0idG9nZ2xlbmRwaSh0aGlzKSI+IFRvZ2dsZSBBbGw8L2 X l SmZvciBrLHYgaW4gcGFp
cnMoc29ydGVkX25kcGlfZmluYWw=
cb$�?KSBkbwogIEhUTUxjb250ZW50ID0gSFRNTGNvbnRlbnQuLltbPGxpPjxpbnB1dCB0eXBlPSJj
aGVja2JveCIgbmFtZT0ibDdwcm90b3MiIGNsYXNz ,uZHBpY2hlY2tib3giIF KiAgaWYg
KG5kcGlfc2VsZWN �
RfcHJvdG8=
cb$�?cyA9PSBuaWwgb3IgaGFzS2V5KHYsIG5kcGlfc2VsZWN0ZWRfcHJvdG9zKSkgdGhlbiBIVE1M
Y29udGVudCA9IEhUTUxjb25 450Li4iY2hlY2tlZCIg kCiAgSFRNTGNvbnRlbnQg �I
@M�L4uW1sgdmFsdWU=
cb$�2PSJdXS4udi4uW1siPiB�8L2xpPl1dCmVuZAoKSFRNTGNvbnRlbnQgPSBIVE1M
Y29udGVudC`H8L3VsPgo @Rpdj4KPC9kaXY+CjwvZGl2 KPG iBpZD0icHJlZl9w
YXJ0X3NlcGFyYXRvciI+PGhyLz4=
cb$�?PC9kaXY+Cgo8ZGl2IGNsYXNzPSJjb250cm9sLWdyb3VwIj4mbmJzcDs8L2Rpdj4KICA8YnV0
dG9uIGlk 8yZXBvcnRfZmlsdGVyX3N1Ym1pdCIgY2xhc3M9ImJ0biBidG4tcHJpbWFyeSBi H4tYmxvY2siPl�8BGaWw=
cb$�?dGVyPC9idXR0b24+CjwvZGl2PgoKPHNjcmlwdD4KICAkKCI Vwb3J0X2ZpbHRlcl9zdWJt
aXQiKS5jbGljayhmdW5jdGlvbiAoKSB7CiAgICB2YXIgaW50ZnNfc3Ry nID0gIiIsIG5k
cGl�	7CiAgICA=
cb$�?JCgnLmludGZjaGVja2JveCcpLmVhY2goZnVuY3Rpb24oaSwgb2JqKSB7CiAgIC GlmICgk
KHRoaXM 8lzKCc6Y2hlY2tlZ L�0 4aW50ZnNfc3Ry nICs9ICQodGhp
cykudmFsKCk�eCAgaW4=
cb$�>dGZzX3N0cmluZyArPSAifHwiOwogICA B9Ci�KTsK�QoJy5uZHBpY2hlY2ti
b3gnKS5lYWNoKGZ1bmN0aW9uKGksIG9iaikge�TpZiAoJCh0aGlz 7pcygnOmNo
ZWNrZWQ L�0AgIG4=
cb$�?ZHBpX3N0cmluZyArPSAkKHRoaXMpLnZh
bCgpOwogICA�G5kcGlfc3RyaW5nICs9ICJ8
fCI7Ci�$H0K`0H0@<�	ZhciB1cmwg diIjs�GlmIChpbnRmc19z
dHJpbmcgIT0gIiIpIHsKICAgICA=
cb$�?IHVybCA9ICddXS4ubnRvcC5nZXRIdHRwUHJlZml4KCkuLltbL2x1YS9wcm8vbW9kdWxlcy9z
 0fcmVwb3J0X3ByZWZzLm ,T9p Tmcz0nK2ludGZzX3N0cmluZzsKICAgIH0�Glm
IChuZHBp� $yAhPSAiIik=
cb$�'IHsKICAg@dXJsID0�CsgJyZuZHBpPScrbmRwaV9zdHJpbmc7C i@3B9Cgo`;
aWYgKHVybCAhPSAiIikgew� \kLmFqYXgo�gIHR5cGU6ICdHRVQnLAog
 ,@0  LDo`�LAogICA=
cb$�9ICAgICBhc3luYzogZmFsc2UsCi@�c3VjY2Vzc@nVuY3Rpb24oY29udGVudCkg
eyB9� 4H0pOwo XAgfQoK@IHZhciBuZXdfdXJsID0gJ11 ;hUTUxjb250ZW50
@SFRNTGNvbnRlbnQuLm50b3A=
cb$�?LmdldEh0dHBQcmVmaXgoKQpIVE1MY29udGVudCA9IEhUTUxjb250ZW50Li5bWy9sdWEvcHJv
L3JlcG9ydC5@/ZXBvY2g9XV0uLmVwb2No�4ZudW1fbWludXRlcz1dXS4ubnVtX21p
 0ZXMuLltbJztdXQpIVE1MY28=
cb$�?bnRlbnQgPSBIVE1MY29udGVudC4uW1sKICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gbmV3
X3VybD�0fSk7Cjwvc2NyaXB0PgoKPC9kaXY+Cgo8L2Rpdj4� +ZGl2PiA8
IS0tIHBhc3N3b3JkX2RpYWxvZyA=
cb$??LS0+CgpdXQoKcmV0dXJuIEhUTUxjb250ZW50Cg==
