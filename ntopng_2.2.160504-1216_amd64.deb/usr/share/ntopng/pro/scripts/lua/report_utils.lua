�V1�   cb$�#LS0K gKEMpIDIwMTMtMTUgLSBudG9wLm9yZwotLQoKZGlycyA9IG50b3AuZ2V0R`gp
CnBhY2thZ2UucGF0aC@(RpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVhL21vZHVs
ZXMvPy5sdWE7I`,
BwYWNrYWc=
cb$�?ZS5wYXRoCnBhY2thZ2UucGF0aCA9IGRpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVh
L3Byby9tb2R1bGVzLz8u@OyIgLi4gcGFja2Fn� pgpyZXF1aXJlICJ BvcnQt
cHJpbnRfdXRpbHMi (	mdW5jdGk=
cb$�?b24gZ2V0UmVwb3J0RmlsZXMoKQogIHJldHVybiBudG9wLmxpc3RSZXBvcnRzKCkKZW5kCgpm
dW5jdGlv ,nZXRVc2VkUERG XuZGVyZXI�TAicGRmdGV4IgplbmQKCmZ1
bmN0aW9uIGhhdmVQREZSZW5kZXI=
cb$�+ZXIocmVuZGVy pCiAgbG9jYWwg  0@aWYgKG5vdCByZW5kZXJlcikgdGhlbgogICAg
@,dXJuIGZhbHNl@8@,@LS0gU3RyYW5nZSBhcyBp LtaWdo zZWVtLCB0aGUg
YmVsb3cgaXMgcG9ydG
FibGUKICA=
cb$�?bG9jYWwgaGFuZGxlID0gaW8ucG9wZW4ocmV VyZXIuLiIgLXYgMj4mMSIpCiAgZm9yIGxp
bmU 8 4� HOmxpbmVzKCkgZG8KICAg (vY2FsIG1hdGNo@lbmls@HICBpZiAo
bGluZSB+PSBuaWwpIHRoZW4KICA=
cb$�?ICAgIG1hdGNoID0gc3RyaW5nLmZpbmQobGluZTpsb3dlcigpLCByZW5kZXJ 4uIiBbJXcl
Ll0rIikK�PVuZAog@aWYgK�`H49IG5pbCkgdGhlbi LXQgPSB0cnVlIGJy
ZWFrCi �CBlbHNlIHJldCA9IGY=
cb$�-YWxzZSBlbmQKIC� oYW5kbGU6Y2xvc2UoKQogIHJldHVybiByZXQKZ #CgpmdW5j
dGlv tYWtlUmVwb3J0KG51bV9ob3Vycywgbm9fb3B0cyk@lpZiAo 0IGhhdmVQREZS
@UZXJlcihnZXRVc2VkUERGUmU=
cb$�?bmRlcmVyKCkpKSB0aGVuCiAgICBudG9wLnF1ZXVlQWxlcnQoMiwgNCwgIkZha ZCB0byBn
ZW5 H	F0ZSByZXBv ,
gKGluc3RhbG 0i4uZ2V0VXNlZFBERlJl�|uLiIp@ 
�} DR1cm4 8
IKICBlbmQ=
cb$�?CiAgbG9jYWwgdHN0YW1wID0gb3MuZGF0ZSgiJVklbSVkIikKICBsb2NhbCBmc aCA9IGZp
eFBhdGgoInJlcG9ydC0iLi50c3RhbXAuLiIucGRm�Dkb19wcmludGFibGVfcmVwb3J0
KG9zLnRpbWUoKSwgbnVtX2hvdXI=
cb$�?cywgMTUsIGZwYXRoKQogIGlmIChudG9wLmV4aXN0cyhmaXhQ`#GRpcnMud29ya2luZ2Rp
ciAuLiAiL3JlcG9ydHMvIi4uZnBhdGgpKSkgdGhlbg `CAgbnRvcC5xdWV1ZUFsZXJ0KDAs
IDQsICJSZXBvcnQg�Dg=
cb$�?Li4iIGNyZWF0ZWQuIikKICAgIHJldHVybiBmcGF0aAogIGVsc2U�G50b3AucXVldWVB
bGVydCgyLCA0 iRmFp kIHRvIGdlbmVyYXRl@XcG9 +AiLi5�\C4 x4iKQog
@}cmV0dXJuICIiCiAgZW5kCmU=
cb$$bmQK
