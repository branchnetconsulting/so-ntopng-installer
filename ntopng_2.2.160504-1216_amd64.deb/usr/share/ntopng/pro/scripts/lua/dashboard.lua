�V1�   cb$�#LS0K gKEMpIDIwMTMtMTUgLSBudG9wLm9yZwotLQoKZGlycyA9IG50b3AuZ2V0R`gp
CnBhY2thZ2UucGF0aC@(RpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVhL21vZHVs
ZXMvPy5sdWE7I`,
BwYWNrYWc=
cb$�?ZS5wYXRoCnBhY2thZ2UucGF0aCA9IGRpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVh
L3Byby9tb2R1bGVzLz8u@OyIgLi4gcGFja2Fn� pgpyZXF1aXJlICJsdWFfdXRp
bHMi zZW5kSFRUUEhlYWRlcig=
cb$�?J3RleHQvaHRtbDsgY2hhcnNldD1pc28tODg1OS0xJykKCm50b3AuZHVtcEZpbGUoZGlycy5p
bnN0YWxs@IC4uICI@T0cGRvY3MvaW5jL2hlYWRlci5pbmMiKQoKLS0gTk9URTogaW4g
dGhlIGhvbWUgcGFnZSwgZm9vdGU=
cb$�?ci5sdWEgY2hlY2tzIHRoZSBudG9wbmcgdmVyc2lvbgotLSBzbyBpbiBjYXNlIHdlIGNoYW5n
 4pdCwgZm9vdGVyLmx1YSBtdXN0IGFsc28gYmUgdXBkYXRlZAphY3Rp `fcGFnZSA9ICJo
b21lIgpkb2ZpbGUoZG
lycy5pbnM=
cb$�?dGFsbGRpciAuLiAiL3NjcmlwdHMvbHVhL2luYy9tZW51Lmx1YSIpCgptYXhfcm93cyA9IDcK
CnByaW50KCc8 TibGUgY2xhc3M9InRhYmxlIH�LWJvcmRlcmVk� XN0@x
ZWQiPicpCmh1bWFuSWZOYW1lID0=
cb$�?IGdldEludGVyZmFjZU5hbWVBbGlhcyhpZm@UpCnByaW50KCI8dHI+PHRoIHdpZ PTMz
JT4iLi5odW1hbklmTmFtZS4uIjogVG9wIExvY2FsIFRhbGtlcnM8L3 <jx0aCBjb2xzcGFu
PTI+QWN0dW`,yYWZmaWM8L3Q=
cb$�?aD4iKQpwcmludCgiPHRoPiIuLmh1bWFuSWZOYW1lLi4iOiBSZWFsdGltZSBUb3AgQXBwbGlj
YXRpb24gVHJhZmZpYzwvdGg +`Pk5ldHdvcmsgSW50ZXJmYWNlczogUmVhb H ;WU`; 
�<C90cj4iKQoKZm8=
cb$�?ciBudW09MCxtYXhfcm93cyBkbwogICBwcmludCgiPHRyPjx0ZD48ZGl2IGlkPXRhbGtlcnNf
Ii4ubnVtLi4iPjwv@$@dGQ+IikKICAgcHJpbnQoI@HCBhbGlnbj1yaWdodCBjb2xz
cGFuPTI+PGRpdiBpZD10YWxrZXI=
cb$�?c18iLi5udW0uLiJfdHJhZmZpYz48L2Rpdj 3RkPlxuIikKCiAgIGlmKG51bSA9PSAwKSB0
aGVu` C  HByaW50KCc8dGQgcm93c3Bhbj0nLi4obWF4X3Jvd3MrMSk xcgc3R5bGU9
InBvc2l0aW9uOiByZWxhdGl2ZTs=
cb$�)Ij48c3Bhbj@ZnIGlkPSJjaGFydF90b cHBzX3JlYWx0aW1lIiBzdHlsZT0iaGVpZ2h0
OiAzMDBweDsgd2lkdGg6IDk1JTsiPjwv@\��lL3RkPlxuJykKICAg@cHJp
bnQoJzx0ZCByb3dzcGFuPScuLig=
cb$�?bWF4X3Jvd3MrMSkuLicgc3R5bGU9InBvc2l0aW9uOiByZWxhdGl2ZTsiPjxzcGFu@dmcg
aWQ9ImNoYXJ0X2lmYWNlc19 4Fs 4tZSI�XmhlaWdodDogMzAwcHg7IHdpZHRo
OiA5NSU7Ij48L3N2Zz48L3NwYW4=
cb$�?PjwvdGQ+XG4nKQogICBlbmQKCiAgIHByaW50KCc8L3RyPlxuJykKZW5kCgpwcmludCgiPHRy
Pjx0aCB3aWR0aD0zMyU+Ii4uaHVtYW5JZk5hbWUuLiI6IFRvcCBSZW1 |UgRGVzdGluYXRp
b25zPC9 D48dGggYWxpZ249Y2U=
cb$�?bnRlciBjb2xzcGFuPTI+QWN0dWFsIFRyYWZmaWM8L3RoPiIpCnByaW50KCI8dGg+Ii4uaHVt
YW5JZk5hbWUuLiI6 <vcCBBcHBsaWNhdGlvbiBUcmFmZmljIExhc3QgRGF5IFZpZXc`d
Pjx0aD5OZXR3b3JrIEludGVyZmE=
cb$�?Y2VzOiBMYXN0IERheSBWaWV3PC90aD48L3RyPiIpCgoKZm9yIG51bT0wLG1heF9yb3dzIGRv
CiAgIHByaW50KCI8dHI+PHRkPjxkaXYgaWQ9cmVtb3RlX3RhbGtlcnNfIi4ubnVtLi4iPjwv
ZGl2@dGQ+IikKICAgcHJpbnQ=
cb$�5KCI8dGQgYWxpZ249cmlnaH 29sc3Bhbj0yPjxkaXYgaWQ Vtb3RlX3RhbGtlcnNfIi4u
bnVtLi4i yYWZmaWM+PC9@8@0ZD5cbiIpCgogICBpZihudW0gPT0gMCkgdGhlb 
ICA@  w �udCgnPHRkIHJvd3M=
cb$�?cGFuPScuLihtYXhfcm93cysxKS4uJyBzdHlsZT0icG9zaXRpb246IHJlbGF0aXZlOyI+PHNw
YW4@2ZyBpZD0iY2hhcnRfdG9wYXBwc19sYXN0ZGF5Ii�XaGVpZ2h0OiAzMDBw
eDsgd2lkdGg6IDk1JTsiPjwvc3Y=
cb$�=Zz48L3NwYW4+PC90ZD5cbicpCiAgIC HByaW50KCc8dGQgcm93c3Bhbj0nLi4obWF4X3Jv
d3MrMSkuLicgc3R5bGU9InBvc2l0aW9uOiByZWxhdGl2ZTsiPjxzcGFu@dmcgaWQ9ImNo
YXJ0X2lmYWNlc19sYXN	0ZGF5IiA=
cb$�?c3R5bGU9ImhlaWdodDogMzAwcHg7IHdpZHRoOiA5NSU7Ij48L3N2Zz`wYW4+PC90ZD5c
bicpCiAgIGVuZAoKICAgcHJpbnQoJzwvdHI+XG4nKQplbmQKCnByaW50KCc T
RyPlxuJykK
�4GFi �	+JykKCnA=
cb$p?cmludCBbWwoKPCEtIFJlcGxhY2Ugd2l0aCBkaXY hlbiBwb3NzaWJsZSAhLT4�3Coq
Kioq�;�HICE+Cgo8dGFibGU=
cb$�?IGJvcmRlcj0wIHdpZHRoPTEwMCU+Cgo8dHI+Cjx0ZCB2YWxpZ249dG9wPgpdXSAKZG9maWxl
KGRpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVhL3Byby9pbmMvZGFzaGJvYXJkX3Rv
cF90 irZXJzLmx1YSIpIApkb2Y=
cb$�4aWxlKGRpcnMuaW5zdGFsb@iAuLiAiL3NjcmlwdHMvbHVhL3Byby9pbmMvZGFzaGJvYXJk
X3RvcF9odHRwX3NpdGVzLmx1YSIpIApw DudCBbWwo8L3RkPgo8dGQgd2lkdGg9MzMlPgpd
XQpkb2ZpbGUoZGlycy5pbnN0YWw=
cb$�?bGRpciAuLiAiL3NjcmlwdHMvbHVhL3Byby9pbmMvZGFzaGJvYXJkX3RvcF9hcHBsaWNhdGlv
bnMu@4IikgCnByaW50IFtbCjwvdGQ+Cjx0ZCB3aWR0aD0zMyU+Cl1dCmRvZmlsZShkaXJz
Lmluc3RhbGx IgLi4gIi9zY3I=
cb$�?aXB0cy9sdWEvcHJvL2luYy9kYXNoYm9hcmRfaW50ZXJmYWNlcy5@+iKSAK /pbnQgW1sK
PC90ZD4K@cj4KCjwvdGFibGU+Cl1dCgpkb2Zp oZGly H <N0YWxs@IC4uICIv
c2Ny�� }	jL2Zvb3Q=
cb$,ZXIubHVhIik=
